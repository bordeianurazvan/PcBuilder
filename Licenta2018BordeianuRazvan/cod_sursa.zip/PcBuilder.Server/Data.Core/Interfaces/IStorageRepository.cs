﻿using Data.Core.Domain;

namespace Data.Core.Interfaces
{
    public interface IStorageRepository: IGenericRepository<Storage>
    {
        
    }
}