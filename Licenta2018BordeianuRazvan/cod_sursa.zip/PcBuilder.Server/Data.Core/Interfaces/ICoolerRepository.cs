﻿using Data.Core.Domain;

namespace Data.Core.Interfaces
{
    public interface ICoolerRepository: IGenericRepository<Cooler>
    {
        
    }
}