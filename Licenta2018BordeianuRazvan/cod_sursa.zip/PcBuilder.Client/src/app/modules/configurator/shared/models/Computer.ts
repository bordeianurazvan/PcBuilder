export class Computer {
  caseId: string;
  cpuId: string;
  coolerId: string;
  motherboardId: string;
  ramId: string;
  videocardId: string;
  storageId: string;
  powersupplyId: string;
  constructor() {
    this.caseId = '';
    this.cpuId = '';
    this.coolerId = '';
    this.motherboardId = '';
    this.ramId = '';
    this.videocardId = '';
    this.storageId = '';
    this.powersupplyId = '';
  }
}
